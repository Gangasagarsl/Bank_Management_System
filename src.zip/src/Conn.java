import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class Conn {
    Connection c;
    Statement s;

    //data base connetion_JDBC  connectivity

    public Conn(){
//        Connection c;
//        Statement s;
        try {
            //connection create
            c=DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem","root","Ganga@#123");
            s=c.createStatement();
        }catch (Exception e){
            System.out.println(e);
        }
    }

}
